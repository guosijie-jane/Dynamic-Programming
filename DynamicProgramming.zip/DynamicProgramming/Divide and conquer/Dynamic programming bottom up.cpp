/*Highlighting the differences between top-down and bottom-up:

top - down generally starts at the solution, and recursively computes all the dependencies using memoization
bottom - up starts builds up bigger solutions from smaller ones, until it reaches the final solution
*/
#include <iostream>
#include <cstdio>
using namespace std;
//Recursion (Top-Down):
int f1(int n)
{
	int result[2] = { 0, 1 };
	if (n < 2)
		return result[n];

	int  fib_pre1 = 1;
	int  fib_pre2 = 0;
	int  fib = 0;
	for (int i = 2; i <= n; ++i)   //computer from bottom to top
	{
		fib = fib_pre1 + fib_pre2;
		fib_pre2 = fib_pre1;
		fib_pre1 = fib;
	}
	return fib;//return value

}

int main()
{
	int n;
	while (cin >> n) {
		cout << f1(n) << endl;
	}
	return 0;
}
