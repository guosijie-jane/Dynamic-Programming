
#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;
//Formula
double calc(double a, int b) {
	double r = 1;
	while (b) {
		if (b & 1) {
			r *= a;
		}
		a *= a;
		b >>= 1;
	}
	return r;
}

int main()
{
	int n, N;
	int result;
	cout << "Please input number n" << endl;
	cin >> N;
	while (N--) {
		cin >> n;
		if (n == 1) result = 0;
		else result = (int)((1 / sqrt(5)) * (calc((1 + sqrt(5)) / 2, n) + calc((1 - sqrt(5)) / 2, n)) + 0.5);
		cout << "The result is " << endl;
		cout << result << endl;
	}
	return 0;
}
