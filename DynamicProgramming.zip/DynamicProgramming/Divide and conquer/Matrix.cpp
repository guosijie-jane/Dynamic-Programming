#include <iostream>
#include <cstdio>

using namespace std;
//Matrix
# define MOD 10000;
struct matrix {  //use a struct to store matrix
	int node[2][2];
}ans, tem;

matrix muti(matrix a, matrix b) {  //Matrix a times Matrix b, return Matrix
	matrix temp;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			temp.node[i][j] = 0;
			for (int k = 0; k < 2; k++) {
				temp.node[i][j] = (temp.node[i][j] + (a.node[i][k] * b.node[k][j])) % MOD;
			}
		}
	}
	return temp;
}

int quick_m(int b) {
	ans.node[0][0] = ans.node[1][1] = 1;  //initialize ans to unit matrix
	ans.node[0][1] = ans.node[1][0] = 0;
	tem.node[0][0] = tem.node[0][1] = tem.node[1][0] = 1;
	tem.node[1][1] = 0;
	while (b) {   //use into matrix multiplication
		if (b & 1) {
			ans = muti(ans, tem);
		}
		tem = muti(tem, tem);
		b >>= 1;
	}
	return ans.node[0][1];  //return F(n)
}

int main()
{
	int n;
	while (cin >> n) && n != -1) {
	cout << quick_m(n) << endl;
	}
	return 0;
}
