#include "stdafx.h"
#include <iostream> 
#include <map> 
using namespace std;
//Memorization
void input(int &n);
int f(int n, map<int, int>);

int main()
{
	map<int, int>   my_Map;
	int n;
	input(n);
	cout << "f(" << n << ")=" << f(n, my_Map) << endl;
	return 0;
}

void input(int &n)
{
	cout << "Please input number n" << endl;
	cin >> n;
}

int f(int n, map<int, int> my_Map)
{
	if (n == 0 || n == 1)
	{
		return 1;
	}
	else
	{
		map<int, int>::iterator iter = my_Map.find(n);
		if (iter == my_Map.end())
		{
			int temp = f(n - 1, my_Map) + f(n - 2, my_Map);
			my_Map.insert(pair<int, int>(n, temp));
			return temp;
		}
		else
		{
			return iter->second;
		}
	}
}
