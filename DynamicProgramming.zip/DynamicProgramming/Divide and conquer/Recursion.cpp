#include <iostream>
#include <cstdio>
using namespace std;
//Recursion (Top-Down):
int f(int n) {
	if (n == 0) return 0;
	if (n == 1) return 1;
	else {
		return f(n - 1) + f(n - 2);
	}

}

int main()
{
	int n;
	while (cin >> n) {
		cout << f(n) << endl;
	}
	return 0;
}
