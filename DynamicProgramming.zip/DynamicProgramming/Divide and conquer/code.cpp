#include "stdafx.h"
#include<iostream> 
#include <cstdio>
#include <map> 
#include <cmath>
#include <ctime>
using namespace std;
# define MOD 10000;
struct matrix {  //use a struct to store matrix
	int node[2][2];
}ans, tem;

void input(int &n);
int f(int n);
int f1(int n);
int f2(int n, map<int, int>);



void input(int &n)
{
	cout << "Please input number n" << endl;
	cin >> n;
}
//Recursion (Top-Down):
int f(int n) {
	if (n == 0) return 0;
	if (n == 1) return 1;
	else {
		return f(n - 1) + f(n - 2);
	}
}
//Dynamic programming (Bottom-Up):
int f1(int n)
{
	int result[2] = { 0, 1 };
	if (n < 2)
		return result[n];

	int  fib_pre1 = 1;
	int  fib_pre2 = 0;
	int  fib = 0;
	for (int i = 2; i <= n; ++i)   //computer from bottom to top
	{
		fib = fib_pre1 + fib_pre2;
		fib_pre2 = fib_pre1;
		fib_pre1 = fib;
	}
	return fib;//return value

}
//Memorization
int f2(int n, map<int, int> my_Map)
{
	if (n == 0) return 0;
	if (n == 1) return 1;
	else
	{
		map<int, int>::iterator iter = my_Map.find(n);
		if (iter == my_Map.end())
		{
			int temp = f2(n - 1, my_Map) + f2(n - 2, my_Map);
			my_Map.insert(pair<int, int>(n, temp));
			return temp;
		}
		else
		{
			return iter->second;
		}
	}
}
// Matrix
matrix muti(matrix a, matrix b) {  //Matrix a times Matrix b, return Matrix
	matrix temp;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			temp.node[i][j] = 0;
			for (int k = 0; k < 2; k++) {
				temp.node[i][j] = (temp.node[i][j] + (a.node[i][k] * b.node[k][j])) % MOD;
			}
		}
	}
	return temp;
}

int quick_m(int b) {
	ans.node[0][0] = ans.node[1][1] = 1;  //initialize ans to unit matrix
	ans.node[0][1] = ans.node[1][0] = 0;
	tem.node[0][0] = tem.node[0][1] = tem.node[1][0] = 1;
	tem.node[1][1] = 0;
	while (b) {   //use into matrix multiplication
		if (b & 1) {
			ans = muti(ans, tem);
		}
		tem = muti(tem, tem);
		b >>= 1;
	}
	return ans.node[0][1];  //return F(n)
}
//Formula
double calc(double a, int b) {
	double r = 1;
	while (b) {
		if (b & 1) {
			r *= a;
		}
		a *= a;
		b >>= 1;
	}
	return r;
}
int formula(int n)
{
	int result;
	if (n == 0) result = 0;
	if (n == 1) result = 1;
	else result = (int)((1 / sqrt(5)) * (calc((1 + sqrt(5)) / 2, n) + calc((1 - sqrt(5)) / 2, n)) + 0.5);
	return result;

}

int main()
{
	map<int, int>   my_Map;
	int n;
	input(n);

	clock_t startTime_For_Fibonacci_top_down;
	clock_t endTime_For_Fibonacci_top_down;
	clock_t startTime_For_Fibonacci_bottom_up;
	clock_t endTime_For_Fibonacci_bottom_up;
	clock_t startTime_For_Fibonacci_memorization;
	clock_t endTime_For_Fibonacci_memorization;
	clock_t startTime_For_Fibonacci_matrix;
	clock_t endTime_For_Fibonacci_matrix;
	clock_t startTime_For_Fibonacci_formula;
	clock_t endTime_For_Fibonacci_formula;
	//Recursion (Top-Down): start and end time of execution
	startTime_For_Fibonacci_top_down = clock();
	cout << "f_Top_Down(" << n << ")=" << f(n) << endl;
	endTime_For_Fibonacci_top_down = clock();

	//Dynamic programming (Bottom-Up):start and end time of execution
	startTime_For_Fibonacci_bottom_up = clock();
	cout << "f_Bottom_Up(" << n << ")=" << f1(n) << endl;
	endTime_For_Fibonacci_bottom_up = clock();

	//Memorization:start and end time of execution
	startTime_For_Fibonacci_memorization = clock();
	cout << "f_Memorization(" << n << ")=" << f2(n, my_Map) << endl;
	endTime_For_Fibonacci_memorization = clock();

	//Matrix:start and end time of execution
	startTime_For_Fibonacci_matrix = clock();
	cout << "f_Matrix(" << n << ")=" << quick_m(n) << endl;
	endTime_For_Fibonacci_matrix = clock();

	//Formula:start and end time of execution
	startTime_For_Fibonacci_formula = clock();
	cout << "f_Formula(" << n << ")=" << formula(n) << endl;
	endTime_For_Fibonacci_formula = clock();

	cout << "Execution time for Recursion (Top-Down)�� " << (endTime_For_Fibonacci_top_down - startTime_For_Fibonacci_top_down) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
	cout << "Execution time for Dynamic programming (Bottom-Up)�� " << (endTime_For_Fibonacci_bottom_up - startTime_For_Fibonacci_bottom_up) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
	cout << "Execution time for Memorization�� " << (endTime_For_Fibonacci_memorization - startTime_For_Fibonacci_memorization) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
	cout << "Execution time for Matrix�� " << (endTime_For_Fibonacci_matrix - startTime_For_Fibonacci_matrix) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
	cout << "Execution time for Formula�� " << (endTime_For_Fibonacci_formula - startTime_For_Fibonacci_formula) / (1.0*CLOCKS_PER_SEC) << "second" << endl;

	system("Pause");
	return 0;
}

