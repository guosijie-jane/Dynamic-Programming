//Sijie Guo's FYP Dynamic Programming Project
#include "stdafx.h"
#include <iostream>
#include "vector"
#include "stack"
using namespace std;
#define INFINITE 10000          // The 40 weight


// graph and adjacent matrix
struct Graph
{
	int     arrMatrix[40][40];    // adjacent matrix max 40
	int     vertexNum;
	int     matrixNum;
};
//read in data of graph
void inputGraph(Graph * pGraph)
{
	cout << "Please input the number of vertexes and edges: ";
	cin >> pGraph->vertexNum;
	cin >> pGraph->matrixNum;
	cout << "Please input row and col of adjacent matrix:" << endl;
	for (int row = 0; row < pGraph->vertexNum; ++row)
	{
		for (int col = 0; col < pGraph->vertexNum; ++col)
		{
			cin >> pGraph->arrMatrix[row][col];
		}
	}
}
//floyd algorithm for short path
void floyd(int  arrDist[][40], int  arrPath[][40], int  vertexNum)
{
	// initilize  arrPath
	for (int i = 0; i < vertexNum; ++i)
	{
		for (int j = 0; j < vertexNum; ++j)
		{
			arrPath[i][j] = i;
		}
	}

	for (int k = 0; k < vertexNum; ++k)
	{
		for (int i = 0; i < vertexNum; ++i)
		{
			for (int j = 0; j < vertexNum; ++j)
			{
				if (arrDist[i][k] + arrDist[k][j] <  arrDist[i][j])
				{
					// find a shorter path
					arrDist[i][j] = arrDist[i][k] + arrDist[k][j];

					arrPath[i][j] = arrPath[k][j];
				}
			}
		}
	}
}
// print path
void printGraph(int  arrDist[][40], int  arrPath[][40], int  vertexNum)
{
	cout << "Source -> Dest   Distance    Path" << endl;

	for (int i = 0; i < vertexNum; ++i)
	{
		for (int j = 0; j < vertexNum; ++j)
		{
			if (i != j)   // if vertex is not itself
			{
				cout << i + 1 << " -> " << j + 1 << "\t\t";
				if (arrDist[i][j] == INFINITE)    // Doesn't exist path from i to j
				{
					cout << "INFINITE" << "\t\t";
				}
				else
				{
					cout << arrDist[i][j] << "\t\t";
					//As we add shortest path from back to front, we push vertex into stack and pop later to print output
					stack<int> verticesSet;
					int k = j;

					do
					{
						k = arrPath[i][k];
						verticesSet.push(k);
					} while (k != i);

					cout << verticesSet.top() + 1;
					verticesSet.pop();

					unsigned int vlength = verticesSet.size();
					for (unsigned int gIndex = 0; gIndex < vlength; ++gIndex)
					{
						cout << " -> " << verticesSet.top() + 1;
						verticesSet.pop();
					}

					cout << " -> " << j + 1 << endl;
				}
			}
		}
	}
}
// test result
int main(void)
{
	Graph testGraph;
	inputGraph(&testGraph);

	int arrDist[40][40];
	int arrPath[40][40];

	// initialize arrDist
	for (int i = 0; i < testGraph.vertexNum; ++i)
	{
		for (int j = 0; j < testGraph.vertexNum; ++j)
		{
			arrDist[i][j] = testGraph.arrMatrix[i][j];
		}
	}

	floyd(arrDist, arrPath, testGraph.vertexNum);

	printGraph(arrDist, arrPath, testGraph.vertexNum);

	system("pause");// wait to print the whole graph and paths
	return 0;
}


