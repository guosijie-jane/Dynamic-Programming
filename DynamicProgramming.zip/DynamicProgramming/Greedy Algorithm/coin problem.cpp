#include "stdafx.h"
#include <iostream>
#include <ctime>
using namespace std;
#define N 4   
#define VALUE1 11            //coin values 11 (changeable)
#define VALUE2 5                   //coin values 5 (changeable)
#define VALUE3 1			//coin values 1 (don't change, avoid no solution)
#define MAX_amount 1000             //Upper-bound of sum
int DP_calcu_times = 0; // Dynamic programming calculation times
int Greedy_calcu_times = 0; // Greedy algorithm calculation times

							/************************** Dynamic programming *******************************

							int Num[MAX_amount];                  //Num[i] store the min amount to get sum i
							int Value_amount[N][MAX_amount];         //Value_amount[i][j] store the amout of VALUEi to get amount of j
							Num[i] = i;          0<= i <=4
							Num[i] = min(Num[i-VALUE1]+1,Num[i-VALUE2]+1,Num[i-VALUE3]+1)
							*/

							//-------------------------Get the Minimum ---------------------------------
int min(int a, int b, int c) {
	return a<b ? (a<c ? a : c) : (b<c ? b : c);
}
//------------------------Get the optimal value---------------------------------
int DP_amount(int amount, int Num[]) {
	//The amount of coins to get the sum of amount	

	int i;
	for (i = 0; i <= VALUE2; i++) {								 //fully use value2 for sum of 0-4  
		Num[i] = i;
	}
	for (i = VALUE2; i <= amount; i++) {		//use various types of coins since value 5
		if (i - VALUE1 >= 0) {								 //if the sum more than 11, coins value 11 can be used
															 //pick the smallest amount of amount to use among 11, 5 and 1
			Num[i] = min(Num[i - VALUE1] + 1, Num[i - VALUE2] + 1, Num[i - VALUE3] + 1);
		}
		else {										     //pick the smallest amount of amount to use between 5 and 1
			Num[i] = (Num[i - VALUE2] + 1) < (Num[i - VALUE3] + 1) ? (Num[i - VALUE2] + 1) : (Num[i - VALUE3] + 1);
			//			Num[i] = min(Num[i-VALUE2]+2,Num[i-VALUE2]+1,Num[i-VALUE3]+1); 
		}
	}
	return Num[amount];
}
//-------------------------Get optimal result---------------------------------
void BestChoice(int amount, int Num[], int Value_amount[N][MAX_amount]) {
	//The total amount of coins is stored in Num[amount]
	//use Num[1-3][amount] to store the amount of three types coins separetely
	int i;
	for (i = 0; i<VALUE2; i++) {
		Value_amount[1][i] = 0;
		Value_amount[2][i] = 0;
		Value_amount[3][i] = i;
	}
	for (i = VALUE2; i <= amount; i++) {
		DP_calcu_times++;
		if ((i >= VALUE1) && (Num[i] == (Num[i - VALUE1] + 1))) {   //i is i-11+11, means i-11 with one more value 11
			Value_amount[1][i] = Value_amount[1][i - VALUE1] + 1;     //one more value 11
			Value_amount[2][i] = Value_amount[2][i - VALUE1];       //same amount of value 5 
			Value_amount[3][i] = Value_amount[3][i - VALUE1];       //same amount of value 1
		}
		else if (Num[i] == (Num[i - VALUE2] + 1)) {        //i is i-5 +5  		
			Value_amount[1][i] = Value_amount[1][i - VALUE2];      //same amount of value 11 
			Value_amount[2][i] = Value_amount[2][i - VALUE2] + 1;     //one more value 5
			Value_amount[3][i] = Value_amount[3][i - VALUE2];       // same amount of value 1
		}
		else if (Num[i] == (Num[i - VALUE3] + 1)) {        //i is i-1+1 	  
			Value_amount[1][i] = Value_amount[1][i - VALUE3];    //same amount of value 11 
			Value_amount[2][i] = Value_amount[2][i - VALUE3];    //same amount of value 5 
			Value_amount[3][i] = Value_amount[3][i - VALUE3] + 1;     //one more value 1
		}
		else {
		}
	}
}

/***************************Greedy Algorithm ********************************
Approach��
Value_amount[i] means the number of VALUEi to be used
Use the largest value first and as much as possible
*/
int Greed(int amount, int Value_amount[]) {
	//To get the sum of amount, Value_amount[1-3] stores the amount of three types of coins separetely
	int total = 0;         //Total amount of coins
	Value_amount[1] = 0;
	Value_amount[2] = 0;
	Value_amount[3] = 0;
	for (int i = amount; i >= 1;) {
		Greedy_calcu_times++;
		if (i >= VALUE1) {
			Value_amount[1]++;
			i -= VALUE1;
			total++;
		}
		else if (i >= VALUE2) {
			Value_amount[2]++;
			i -= VALUE2;
			total++;
		}
		else if (i >= VALUE3) {
			Value_amount[3]++;
			i -= VALUE3;
			total++;
		}
		else {
		}
	}
	return total;
}
void main() {
	// Test Dynamic Programming Algorithm
	int i;
	int amount = 20;
	int Num[MAX_amount];                  //Num[i]store the min number to change i
	int Value_amount[N][MAX_amount];         //Value_amount[i][j] is the number of VALUEi to change j
											 //execute time
	clock_t startTime_For_dynamic_programming;
	clock_t endTime_For_dynamic_programming;
	clock_t startTime_For_greedy_algorithm;
	clock_t endTime_For_greedy_algorithm;
	// Test Dynamic Programming Algorithm
	cout << "Dynamic Programming: " << endl;
	cout << "Total amount:   The total number of coins :    number of each value : 11, 5, 1 \n";
	DP_amount(amount, Num);
	BestChoice(amount, Num, Value_amount);
	for (i = 0; i <= amount; i++) {
		startTime_For_dynamic_programming = clock();
		cout << "Num[" << i << "] = " << Num[i] << " , " << Value_amount[1][i] << " , " << Value_amount[2][i] << " , " << Value_amount[3][i] << endl;
		endTime_For_dynamic_programming = clock();
		cout << " Execution time for Dynamic Programming Algorithm�� " << (endTime_For_dynamic_programming - startTime_For_dynamic_programming) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
		cout << " The calculation times of Dynamic Programming Algorithm is: " << DP_calcu_times << endl;
	}


	//Test Greedy Algorithm
	int Value_amount_Greed[4]; //Value_amount_Greed[i] is the number of VALUEi 
	cout << "Greedy Algorithm: " << endl;
	cout << "Total amount:  number of each value : 11, 5, 1 \n";
	for (i = 0; i <= amount; i++) {                 //Test change solution from 0 to 20
		Greed(i, Value_amount_Greed);
		startTime_For_greedy_algorithm = clock();
		cout << "Num[" << i << "] = " << Value_amount_Greed[1] << " , " << Value_amount_Greed[2] << " , " << Value_amount_Greed[3] << endl;
		endTime_For_greedy_algorithm = clock();
		cout << "Execution time for Greedy Algorithm�� " << (endTime_For_greedy_algorithm - startTime_For_greedy_algorithm) / (1.0*CLOCKS_PER_SEC) << "second" << endl;
		cout << "The calculation times of Greedy Algorithm is: " << Greedy_calcu_times << endl;
	}


	//Compare two algorithms
	int dp, grd;                        //Store total number of Dynamic Programming and Greedy Algorithm separately
	int amount1;                          //The total number of amount to change
	cout << "Please input the number of amount to change:\n";
	cin >> amount1;//can be any nonnegative interger (15 is a value can distinguish the two algorithms)
	dp = DP_amount(amount1, Num);          //Dynamic Programming ALgorithm 
	BestChoice(amount1, Num, Value_amount);
	grd = Greed(amount1, Value_amount_Greed); //Greedy ALgorithm
	cout << "Algorithm :   The total number of coins is :     value : 11, 5, 1 " << endl;
	cout << "Dynamic Programming:" << dp << "," << Value_amount[1][amount1] << "," << Value_amount[2][amount1] << "," << Value_amount[3][amount1] << endl;
	cout << "Greedy Algorithm:" << grd << "," << Value_amount_Greed[1] << "," << Value_amount_Greed[2] << "," << Value_amount_Greed[3] << endl;
}
