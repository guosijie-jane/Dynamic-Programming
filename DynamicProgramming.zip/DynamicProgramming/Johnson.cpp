//Sijie Guo's FYP Dynamic Programming Project

#include "stdafx.h"
#include<iostream>
#define Infinity 65535
#define MAX 100
using namespace std;
//end of edge
struct edgeIndex
{
	int no;//No. of vertex
	int weight; //weight of edge
	edgeIndex *next; //next adjacent edge
};
//vertex informatiom
struct vexIndex
{
	char info; //No. of vertex
	edgeIndex *link; //link of the end vertex of edge start with this vertex
};
//Priority Queue
struct priQueue
{
	int no; //No. of vertex
	int weight; //weight of source vertex to this vertex
};
//vertex array
vexIndex adjlist[MAX];
//priority queue
priQueue queue[2 * MAX];
//min weight from source to every vertex
int lowcost[MAX];
//min weight of each vertexes pair
int mincost[MAX][MAX];
//add the min weight of a No. 0 vertex(source) to other vertexes
int dis[MAX];

//build adjacent list of graph
void createGraph(vexIndex *adjlist, int n, int e)
{
	cout << "Please input the vertex information: " << endl;
	for (int i = 1; i <= n; i++)
	{
		cout << "The index of vertex " << i << " is : ";
		cin >> adjlist[i].info;
		adjlist[i].link = NULL;
	}
	cout << "Please input the edge information��" << endl;
	int v1, v2;
	edgeIndex *path;
	int weight1;
	for (int i = 1; i <= e; i++)
	{
		cout << "The source and destination vertexes of edge" << i << " is ��";
		cin >> v1 >> v2;
		cout << "Please input the weight of this edge��";
		cin >> weight1;
		path = (edgeIndex*)malloc(sizeof(edgeIndex));
		path->no = v2;
		path->weight = weight1;
		path->next = adjlist[v1].link;
		adjlist[v1].link = path;
	}
	//add vertex 0, distance to every other vertex is 0
	adjlist[0].info = '0';
	adjlist[0].link = NULL;
	for (int i = n; i >= 1; i--)
	{
		dis[i] = 0;
		path = (edgeIndex*)malloc(sizeof(edgeIndex));
		path->no = i;
		path->weight = 0;
		path->next = adjlist[0].link;
		adjlist[0].link = path;
	}
}
//calculate shortest distance from vertex 0 to all vertexes by bellman_ford algorithm 
bool bellman_ford(vexIndex *adjlist, int *d, int n)
{
	dis[0] = 0;
	edgeIndex *path;
	for (int j = 1; j <= n; j++)
	{
		for (int i = 0; i <= n; i++)
		{
			path = adjlist[i].link;
			while (path != NULL)
			{
				if (dis[path->no]>dis[i] + path->weight)
					dis[path->no] = dis[i] + path->weight;
				path = path->next;
			}
		}
	}
	for (int i = 0; i <= n; i++)
	{
		path = adjlist[i].link;
		while (path != NULL)
		{
			if (dis[path->no]>dis[i] + path->weight)
				return false;
			path = path->next;
		}
	}
	return true;
}
//in Johnson's algorithm��update nonnagative weight of every edge
void reweightG(int *d, const int n)
{
	edgeIndex *path;
	for (int i = 0; i <= n; i++)
	{
		path = adjlist[i].link;
		while (path != NULL)
		{
			path->weight = path->weight + dis[i] - dis[path->no];
			path = path->next;
		}
	}
}
//keep priority of priority queue. the shortest distance from source to every node is key in heap
void keep_fibheap(priQueue *queue, int &num, int i)
{
	int min = i;
	int left = 2 * i, right = 2 * i + 1;
	if (left <= num&&queue[left].weight<queue[i].weight)
		min = left;
	if (right <= num&&queue[right].weight<queue[min].weight)
		min = right;
	if (min != i)
	{
		priQueue q = queue[min];
		queue[min] = queue[i];
		queue[i] = q;
		keep_fibheap(queue, num, min);
	}
}
//insert node into priority queue
void insert_fibheap(priQueue *queue, int &num, int no, int wei)
{
	num += 1;
	queue[num].no = no;
	queue[num].weight = wei;
	int i = num;
	while (i>1 && queue[i].weight<queue[i / 2].weight)
	{
		priQueue q1;
		q1 = queue[i / 2];
		queue[i / 2] = queue[i];
		queue[i] = q1;
		i = i / 2;
	}
}
//extract the first elememt of the queue
priQueue fibheap_extract_min(priQueue *queue, int &num)
{
	if (num<1)
		return queue[0];
	priQueue que = queue[1];
	queue[1] = queue[num];
	num = num - 1;
	keep_fibheap(queue, num, 1);
	return que;
}
//calculate shortest distance from vertex i to every other vertex by dijkstra algorithm
void dijkstra(vexIndex *adjlist, priQueue * queue, int i, const int n, int &num)
{
	int v = i;
	//lowcost[v] = 0;
	for (int j = 1; j<n; j++)
	{
		edgeIndex *path = adjlist[v].link;
		while (path != NULL)
		{
			if (lowcost[path->no] > lowcost[v] + path->weight)
			{
				lowcost[path->no] = lowcost[v] + path->weight;
				insert_fibheap(queue, num, path->no, lowcost[path->no]);
			}
			path = path->next;
		}
		v = fibheap_extract_min(queue, num).no;
		if (v == 0)
		{
			cout << "Queue is empty! " << endl;
			return;
		}
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	int cases;
	cout << "Please input the number test cases��";
	cin >> cases;
	//Take No.0 element in queue as a tag, return No.0 element if queue is empty
	queue[0].no = 0;
	queue[0].weight = 0;
	while (cases--)
	{
		int n, e;
		cout << "Please input the number of vertexes��";
		cin >> n;
		cout << "Please input the number of edges��";
		cin >> e;
		//initialize elements in queue as 0
		int num = 0;
		int i, j;
		//create adjacent list
		createGraph(adjlist, n, e);
		cout << endl;
		memset(dis, Infinity, sizeof(dis));
		//calculate the shortest distance  from vertex 0 to any other vertexes by bellman_ford algorithm
		bool tag = bellman_ford(adjlist, dis, n);
		if (!tag)
		{
			cout << "There exist negative circle in the graph��" << endl;
			continue;
		}
		//In Johnson algorithm, update each edge with nonegative weight
		reweightG(dis, n);
		//calculate the shortest distance of each pair of vertexes by dijkstra algorithm
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
				lowcost[j] = Infinity;
			lowcost[i] = 0;
			dijkstra(adjlist, queue, i, n, num);
			//update the original weight��which changed in method reweightG()
			for (j = 1; j <= n; j++)
				mincost[i][j] = lowcost[j] + dis[j] - dis[i];
		}
		cout << "The shortest distance of each pair of vertexes��" << endl;
		for (i = 1; i <= n; i++)
			for (j = 1; j <= n; j++)
			{
				cout << "From source vertex(" << i << ":" << adjlist[i].info << ") to destination vertex(" << j << ":" << adjlist[j].info << ") is ��" << mincost[i][j] << endl;
			}
	}
	system("pause");
	return 0;
}
