//Sijie Guo's FYP Dynamic Programming Project
#include "stdafx.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std;
template<class T>
class Sequence {
private:
	int m;
	int n;
	int **LcsMatrix;
	void MatrixInit(int m, int n) {
		LcsMatrix = new int *[m];
		for (int i = 0; i <m + 1; i++) {
			LcsMatrix[i] = new int[n + 1];
		}
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= n; j++) {
				LcsMatrix[i][j] = 0;
			}
		}
	}
public:
	// Time complexity is O(mn)�� Space complexity is O(mn)
	void LcsMatrix(const T&X, const T &Y) {
		m = X.size();
		n = Y.size();
		MatrixInit(m, n);
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (X[i - 1] == Y[j - 1]) {  // vector start from 0                    			
					LcsMatrix[i][j] = LcsMatrix[i - 1][j - 1] + 1; // each LcsMatrix[i,j] entry depends on three other LcsMatrix table entries
				}
				else if (LcsMatrix[i - 1][j] > LcsMatrix[i][j - 1]) {
					LcsMatrix[i][j] = LcsMatrix[i - 1][j];
				}
				else {
					LcsMatrix[i][j] = LcsMatrix[i][j - 1];
				}
			}
		}
	}

	void PrintLcsMatrix(const T &X, int i, int j) {
		if (i == 0 || j == 0)
			return;
		if (LcsMatrix[i][j] == LcsMatrix[i - 1][j - 1] + 1) {
			PrintLcsMatrix(X, i - 1, j - 1);
			cout << X[i - 1];
		}
		else if (LcsMatrix[i][j] == LcsMatrix[i - 1][j]) {
			PrintLcsMatrix(X, i - 1, j);
		}
		else
			PrintLcsMatrix(X, i, j - 1);
	}
};

int main()
{
	const string string1 = "ABCBDAB";
	const string string2 = "BDCABA";
	vector<char> x(string1.begin(), string1.begin() + string1.size());
	vector<char> y(string2.begin(), string2.begin() + string2.size());
	Sequence<vector<char>> seq;
	seq.LcsMatrix(x, y);
	cout << endl << "Thle LcsMatrix of  <" << string1 << "> && <" << string2 << "> is :" << endl;
	seq.PrintLcsMatrix(x, x.size(), y.size());


	int array1[] = { 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1 };
	int array2[] = { 0, 1, 0, 1, 1, 0, 1, 1, 0 };
	vector<int> array1_str(array1, array1 + sizeof(array1) / sizeof(array1[0]));
	vector<int> array2_str(array2, array2 + sizeof(array2) / sizeof(array2[0]));
	Sequence<vector<int>> seq_int;
	seq_int.LcsMatrix(array1_str, array2_str);
	cout << endl << "The LcsMatrix of  <array1> && <array2> is :" << endl;
	seq_int.PrintLcsMatrix(array1_str, array1_str.size(), array2_str.size());
	getchar();
}

