Sijie Guo's FYP Dynamic Programming Project
The website should execute with browser: Chrome, FireFox.
Note that lower IE version doesn't support HTML5 and CSS 3, so there will be error if your broswer is of IE version 6,7 and 8.
The code for each topics is developed in Visual Studio. 
All the code can execute in Visual Studio 2013 and 2015.
Programming language: C++, C#, ASP.NET, HTML5, CSS3, JavaScript.
Note: the implementation of the website is mainly at the front-end with the support of online open source templete from http://www.cssmoban.com/. The Javascript files and CSS files are quoted from the existing templates, which is marked in front of the files.All the web pages are original work with self-developed code and notes.