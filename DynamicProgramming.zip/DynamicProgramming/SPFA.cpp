//Sijie Guo's FYP Dynamic Programming Project
#include <iostream>  
#include <deque>  
#include <stack>  
#include <vector>  
using namespace std;

#define MAXN 100  
#define INF 99999999  

struct edge
{
	int to;
	int weight;
};

vector <edge> adjmap[MAXN]; //adjacent list  
bool in_queue[MAXN];  //whether vertex is in the queue  
int in_sum[MAXN];  //number the vertex in queue  
int dist[MAXN];  //the shortest path from source to each node  
int path[MAXN];  //storage the front vertex before i  
int nodesum;  //number of vertex  
int edgesum;  //number of edge

bool SPFA(int source)
{
	deque <int> dq;
	int i, j, x, to;
	for (i = 1; i <= nodesum; i++)
	{
		in_sum[i] = 0;
		in_queue[i] = false;
		dist[i] = INF;
		path[i] = -1;
	}
	dq.push_back(source);
	in_sum[source]++;
	dist[source] = 0;
	in_queue[source] = true;
	// initialization  

	while (!dq.empty())
	{
		x = dq.front();
		dq.pop_front();
		in_queue[x] = false;
		for (i = 0; i<adjmap[x].size(); i++)
		{
			to = adjmap[x][i].to;
			if ((dist[x] < INF) && (dist[to] > dist[x] + adjmap[x][i].weight))
			{
				dist[to] = dist[x] + adjmap[x][i].weight;
				path[to] = x;
				if (!in_queue[to])
				{
					in_queue[to] = true;
					in_sum[to]++;
					if (in_sum[to] == nodesum)
						return false;
					if (!dq.empty())
					{
						if (dist[to] > dist[dq.front()])
							dq.push_back(to);
						else
							dq.push_front(to);
					}
					else
						dq.push_back(to);
				}
			}
		}
	}
	return true;
}

void Print_Path(int x)
{
	stack <int> s;
	int w = x;
	while (path[w] != -1)
	{
		s.push(w);//push path w into stack
		w = path[w];
	}
	cout << "The shortest path distance from source vertex(vertex 1) to vertex " << x << " is��" << dist[x] << endl;
	cout << "The path is: 1 ";
	while (!s.empty())
	{
		cout << s.top() << " ";
		s.pop();
	}
	cout << endl;
}

int main()
{
	int i, s, e, w;
	edge temp;
	cout << "Please input the number of vertex(es) and edge(s)��";
	cin >> nodesum >> edgesum;
	for (i = 1; i <= nodesum; i++)
		adjmap[i].clear();   //clean adjacent list  
	for (i = 1; i <= edgesum; i++)
	{
		cout << "Please input the No." << i << " th edge's source, end vertexes and weight: ";
		cin >> s >> e >> w;
		temp.to = e;
		temp.weight = w;
		adjmap[s].push_back(temp);
	}
	if (SPFA(1))
	{
		for (i = 2; i <= nodesum; i++)
			Print_Path(i);
	}
	else
		cout << "There exists negative circle in the graph. " << endl;
	return 0;
}

