// bellman ford.cpp : Defines the entry point for the console application.
//Sijie Guo's FYP Dynamic Programming Project

#include "stdafx.h"
#include<iostream>
#define MAX 100
#define Infinity 65535
typedef int DType;
using namespace std;

struct edgeNode
{
	int no; //No. of edge
	char info; //name of edge
	DType weight; //weight of edge
	struct edgeNode * next; //next edge
};

struct vexNode
{
	char info;  //name of vertex
	struct edgeNode *link; //link vertex
};
//storage vertex adjacent list
vexNode adjlist[MAX];
//parent vertex
int parent[MAX];
//the shortest path cost from source vertex to vertex j
DType lowweight[MAX];
//set up adjacent list 
//adjlist is a set of vertexes��n is the number of vertexes, e is number of edges
//return No. of source vertex
int createGraph(vexNode *adjlist, int n, int e)
{
	int i;
	for (i = 1; i <= n; i++)
	{
		cout << "Please input vertex " << i << " 's No.��";
		cin >> adjlist[i].info;
		adjlist[i].link = NULL;
		parent[i] = i;
		lowweight[i] = Infinity;
	}
	edgeNode *p1;
	int v1, v2;
	DType weight;
	for (i = 1; i <= e; i++)
	{
		cout << "Please input No. of edge " << i << " 's source and destination vertexes��";
		cin >> v1 >> v2;
		cout << "Please input the weight of this edge��";
		cin >> weight;
		p1 = (edgeNode*)malloc(sizeof(edgeNode));
		p1->no = v2;
		p1->weight = weight;
		p1->info = adjlist[v2].info;
		p1->next = adjlist[v1].link;
		adjlist[v1].link = p1;
	}
	cout << "Please input the No. of source vertex��";
	int v0;
	cin >> v0;
	lowweight[v0] = 0;
	return v0;
}

void relax(DType *lowweight, int *parent, const int u, const int v, const DType w)
{
	if (lowweight[v]>lowweight[u] + w)//find the shorter path
	{
		lowweight[v] = lowweight[u] + w;
		parent[v] = u;
	}
}
bool Bellman_Ford(vexNode *adjlist, DType *lowweight, int *parent, const int n)
{
	int i, j;
	for (j = 1; j<n; j++)
	{
		for (i = 1; i <= n; i++)
		{
			edgeNode *p1 = adjlist[i].link;
			while (p1 != NULL)
			{
				if (lowweight[i] + p1->weight <lowweight[p1->no])
				{
					lowweight[p1->no] = lowweight[i] + p1->weight;
					parent[p1->no] = i;
				}
				p1 = p1->next;
			}
		}
	}
	//check if there is any negative circle
	for (i = 1; i <= n; i++)
	{
		edgeNode *p2 = adjlist[i].link;
		while (p2 != NULL)
		{
			if (lowweight[p2->no]>lowweight[i] + p2->weight)
				return false;
			p2 = p2->next;
		}
	}
	return true;
}
//print the shortest path from source vertex to vertex i
void printGraph(vexNode *adjlist, int *parent, const int v0, const int i)
{
	if (i == v0)
		cout << "(" << v0 << ":" << adjlist[v0].info << ")  ";
	else
	{
		printGraph(adjlist, parent, v0, parent[i]);
		cout << "(" << i << ":" << adjlist[i].info << ")  ";
	}
}
int _tmain(int argc, _TCHAR* argv[])
{
	int cases;
	cout << "Please input the number of tests��";
	cin >> cases;
	while (cases--)
	{
		int n, e;
		cout << "Please input the number of vertexes��";
		cin >> n;
		cout << "Please input the number of edges: ";
		cin >> e;
		//creat adjacent list
		int v0 = createGraph(adjlist, n, e);
		//call Bellman-Ford method
		bool target = Bellman_Ford(adjlist, lowweight, parent, n);
		//print shortest paths from source vertex to every vertex(No. of vertex: information of vertex)
		for (int i = 1; i <= n; i++)
		{
			cout << "The shortest path from source vertex" << adjlist[v0].info << "to destination vertex " << adjlist[i].info << "is��" << endl;
			printGraph(adjlist, parent, v0, i);
			cout << endl;
			cout << "The cost of this path is��" << lowweight[i] << endl;

		}
	}
	system("pause");
	return 0;
}
