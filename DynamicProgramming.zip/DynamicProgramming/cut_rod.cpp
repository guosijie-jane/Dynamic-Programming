/* cut_rod.cpp :
Cut-Rod problem is to find the best solution of cutting a rod into different length to optimize the overall benefits.
We will give the price of varies length of rod and we want to maximize the total revenue of selling rods
Sijie Guo's FYP Dynamic Programming Project
*/
#include "stdafx.h"
#include <iostream>
using namespace std;
class Rod {
private:
	int rod_Length;
	int *memorized_q;// top down memorization
	int *s;
	int time_recursion, times_topdown, times_bottomup; // count computing times
public:
	Rod(int n) {
		time_recursion = 0;
		times_topdown = 0;
		times_bottomup = 0;
		rod_Length = n;
		s = new int[rod_Length + 1];
		memorized_q = new int[rod_Length + 1];
		for (int i = 0; i <= rod_Length; i++)
			memorized_q[i] = INT_MIN;//initialize memory
	}
	~Rod() {//release space
		delete memorized_q;
		memorized_q = NULL;
	}
	//-----------	Normal Recursion---------------
	int CutRod(int rod_Length, const int prices[]) {
		if (rod_Length == 0)
			return 0;
		int q = -1;
		for (int i = 1; i <= rod_Length; i++) {
			time_recursion++;
			q = __max(q, prices[i] + CutRod(rod_Length - i, prices));
		}
		return q;
	};
	//------------Top-Down(Memoized)-----------------
	int CutRodMemoized(int rod_Length, const int prices[]) {
		if (memorized_q[rod_Length] >= 0)
			return memorized_q[rod_Length];
		int q = INT_MIN;
		if (rod_Length == 0)
			q = 0;
		for (int i = 1; i <= rod_Length; i++) {
			times_topdown++;
			//q = max(q, prices[i] + CutRodMemoized(rod_Length-i, prices));
			if (q < prices[i] + CutRodMemoized(rod_Length - i, prices)) {
				q = prices[i] + CutRodMemoized(rod_Length - i, prices);
				s[rod_Length] = i;
			}
		}
		memorized_q[rod_Length] = q;
		return q;
	};
	//----------------Bottom-Up----------------
	int BottomUpCutRod(int rod_Length, const int prices[]) {
		int *r = new int[rod_Length + 1];
		int *s_bottomup = new int[rod_Length + 1];
		r[0] = 0; // initializa the mininum subproblem
		for (int i = 1; i <= rod_Length; i++) {
			int q = 0;
			for (int j = 1; j <= i; j++) {
				times_bottomup++;
				if (q < prices[j] + r[i - j]) {
					q = prices[j] + r[i - j];
					s_bottomup[i] = j; //return j when q is the max in the ith subproblem
				}
			}
			r[i] = q;
		}
		cout << "BottomUpCutRod solution:";
		int n = rod_Length;
		while (n > 0) {
			cout << "Rod Length when price is maximum: " << s_bottomup[n] << "\n "; //print j when q is max in problem n
			n -= s_bottomup[n];
		}
		cout << endl;
		return r[rod_Length];
	}
	void printTimes() {
		cout << "Calculation times of CutRod Normal Recursion: " << time_recursion << endl;
		cout << "Calculation times of CutRod Top-Down Memorization : " << times_topdown << endl;
		cout << "Calculation times of CutRod Bottom-Up: " << times_bottomup << endl;
		int n = rod_Length;
		cout << "CutRodMemoized solution:";
		while (n > 0) {
			cout << "Rod Length when price is maximum: " << s[n] << "\n "; // print j when q is max in problem n
			n -= s[n];
		}
		cout << endl;
	}
};

int main()
{
	const int prices[] = { 0, 1, 5, 8, 9, 10, 17, 17, 20, 24, 30,35,50,60 };
	int rod_Length = 15;
	Rod rod(rod_Length); //sizeof(prices)/sizeof(prices[0])
	cout << "CutRod Normal Recursion solution: " << rod.CutRod(rod_Length, prices) << endl;
	cout << "CutRod Top-Down Memorization solution: " << rod.CutRodMemoized(rod_Length, prices) << endl;
	cout << "CutRod Bottom-Up solution: " << rod.BottomUpCutRod(rod_Length, prices) << endl;
	rod.printTimes();
	getchar();
	return 0;
}
