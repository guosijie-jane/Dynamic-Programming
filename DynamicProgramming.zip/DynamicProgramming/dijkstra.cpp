// dijkstra.cpp : Defines the entry point for the console application.
//Sijie Guo's FYP Dynamic Programming Project

#include "stdafx.h"
#include <iostream>
#include <limits>
using namespace std;

struct Node { //define vertexes in list
	int adjvex; //the destination vertex of edge
	int weight;// weight of edge
	Node *next; //point to next edge
};

struct SourceNode { // define source vertex
	int nodeName; // name of vertex
	int Degree; // in Degree
	int d; //initilize infinity present the shortest path from source to destination vertex
	bool isKnown; //present whether the shorstest path from source vertex to this vertex is known. True for known, False for unknown
	int parent; //front vertex in shortest path
	Node *link; //point to first edge link to this vertex
};

//G present SourceNode array's first node
//nodeNum is the number of nodes
//edgeNum is the number of edges
void createGraph(SourceNode *G, int nodeNum, int edgeNum) {
	cout << "Build the graph(" << nodeNum << ", " << edgeNum << ")" << endl;
	//initilize the SourceNode
	for (int i = 0; i < nodeNum; i++) {
		G[i].nodeName = i + 1; //position 0 storage vertex v1 and so on
		G[i].Degree = 0; //in degree is 0
		G[i].link = NULL;
	}
	for (int j = 0; j < edgeNum; j++) {
		int begin, end, weight;
		cout << "Please input source vertex, destination vertex and weight: ";
		cin >> begin >> end >> weight;
		// create new node and insert into list
		Node *node = new Node;
		node->adjvex = end - 1;
		node->weight = weight;
		++G[end - 1].Degree; //add 1 on Degree
							 //insert into the first position of list
		node->next = G[begin - 1].link;
		G[begin - 1].link = node;
	}
}

void printGraph(SourceNode *G, int nodeNum) {
	for (int i = 0; i < nodeNum; i++) {
		cout << "The Degree of vertex v" << G[i].nodeName << " is";
		cout << G[i].Degree << ", the edge start with this vertex is: ";
		Node *node = G[i].link;
		while (node != NULL) {
			cout << "v" << G[node->adjvex].nodeName << "(Weight:" << node->weight << ")" << "  ";
			node = node->next;
		}
		cout << endl;
	}
}

//get weight from source vertex to destination vertex
int getWeight(SourceNode *G, int begin, int end) {
	Node *node = G[begin - 1].link;
	while (node) {
		if (node->adjvex == end - 1) {
			return node->weight;
		}
		node = node->next;
	}
}

//calculate the shortest distance from source vertex to every vertex
void Dijkstra(SourceNode *G, int nodeNum, int start) {
	//initilize every vertex
	for (int i = 0; i < nodeNum; i++) {
		G[i].d = INT_MAX; //the initial distance is infinity
		G[i].isKnown = false; // the default distance is unknow
	}
	G[start - 1].d = 0; //The distance to the node itself is 0
	G[start - 1].parent = -1; //This node is source vertex
	while (true) {
		//==== if the shortest distance of every vertex is known then jump out while loop
		int k;
		bool ok = true; //present all the distances are known
		for (k = 0; k < nodeNum; k++) {
			//if there is one vertex's shortest path unknown, set ok to false
			if (!G[k].isKnown) {
				ok = false;
				break;
			}
		}
		if (ok) return;

		//==== search the smallest d amoung all the unknown vertexes and change it to known
		//==== implemation by min-heap
		int i;
		int minIndex = -1;
		for (i = 0; i < nodeNum; i++) {
			if (!G[i].isKnown) {
				if (minIndex == -1)
					minIndex = i;
				else if (G[minIndex].d > G[i].d)
					minIndex = i;
			}
		}
		//===========================================

		cout << "The current picked vertex is: v" << (minIndex + 1) << endl;
		G[minIndex].isKnown = true; //add it into the set of known shortest path
									// take minIndex as source vertex, update all the shortest paths d
		Node *node = G[minIndex].link;
		while (node != NULL) {
			int begin = minIndex + 1;
			int end = node->adjvex + 1;
			int weight = getWeight(G, begin, end);
			if (G[minIndex].d + weight < G[end - 1].d) {
				G[end - 1].d = G[minIndex].d + weight;
				G[end - 1].parent = minIndex; //record the parent vertex of shortest path
			}
			node = node->next;
		}
	}
}

//print the shortest path to destination-1 vertex
void printPath(SourceNode *G, int end) {
	if (G[end - 1].parent == -1) {
		cout << "v" << end;
	}
	else if (end != 0) {
		printPath(G, G[end - 1].parent + 1); //add 1, because parent is No. start from 0
		cout << " -> v" << end;
	}
}
int main() {
	SourceNode *G;
	int nodeNum, edgeNum;
	cout << "Please input the number of vertexes and edges: ";
	cin >> nodeNum >> edgeNum;
	G = new SourceNode[nodeNum];
	createGraph(G, nodeNum, edgeNum);

	cout << "=============================" << endl;
	cout << "Print the information of the Graph:" << endl;
	printGraph(G, nodeNum);

	cout << "=============================" << endl;
	cout << "Call dijkstra alogorithm." << endl;
	Dijkstra(G, nodeNum, 1);

	cout << "=============================" << endl;
	cout << "Print the shortest path of vertexes start from v1: " << endl;
	for (int k = 2; k <= nodeNum; k++) {
		cout << "The distance from v1 to v" << k << " is " << G[k - 1].d << ": ";
		printPath(G, k);
		cout << endl;
	}
}

