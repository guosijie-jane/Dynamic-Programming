// Levenshtein.cpp : Defines the entry point for the console application.
//Sijie Guo's FYP Dynamic Programming Project

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;
int min(int a, int b)
{
	return a < b ? a : b;
}

int Levenshtein_distance(string s, string t)
{
	int source = s.size();
	int target = t.size();
	int **matrix_table = new int*[source + 1];
	for (int i = 0; i < source + 1; i++)
	{
		matrix_table[i] = new int[target + 1];
	}

	for (int i = 0; i < source + 1; i++)
	{
		matrix_table[i][0] = i;
	}

	for (int i = 0; i < target + 1; i++)
	{
		matrix_table[0][i] = i;
	}

	for (int i = 1; i < source + 1; i++)
	{
		for (int j = 1; j< target + 1; j++)
		{
			int d;
			int temp = min(matrix_table[i - 1][j] + 1, matrix_table[i][j - 1] + 1);
			if (s[i - 1] == t[j - 1])
			{
				d = 0;
			}
			else
			{
				d = 1;
			}
			matrix_table[i][j] = min(temp, matrix_table[i - 1][j - 1] + d);
		}
	}

	cout << "**************************" << endl;
	for (int i = 0; i < source + 1; i++)
	{
		for (int j = 0; j< target + 1; j++)
		{
			cout << matrix_table[i][j] << " ";
		}
		cout << endl;
	}
	cout << "**************************" << endl;
	int distance = matrix_table[source][target];

	for (int i = 0; i < source + 1; i++)
	{
		delete[] matrix_table[i];
		matrix_table[i] = NULL;
	}

	delete[] matrix_table;
	matrix_table = NULL;

	return distance;
}

int main(void)
{
	string s;
	string t;
	cout << "source=";
	cin >> s;
	cout << "target=";
	cin >> t;
	int distance = Levenshtein_distance(s, t);
	cout << "distance=" << distance << endl;
	return 0;
}
