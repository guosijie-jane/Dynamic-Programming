/* matrix multiplication.cpp : We state the matrix-chain multiplication problem as follows:
given a chain (A1, A2... An) of n matrices, where for i=1,2,...,n,
matrix Ai has dimension pi-1 * pi fully parenthesize the product A1A2 ...An
in a way that minimizes the number of scalar multiplications.
//Sijie Guo's FYP Dynamic Programming Project
*/
#include "stdafx.h"
#include <iostream>

using namespace std;
class Matrix {
private:
	int n;
	int **m;// original matrix
	int **s;// optimal matrix solution
	int times_topdown, times_bottomup;
public:
	Matrix(int len) {
		n = len;
		m = new int *[n + 1];
		s = new int *[n + 1];
		times_topdown = 0;
		times_bottomup = 0;
		for (int i = 0; i < n + 1; i++) {
			m[i] = new int[n + 1];
			s[i] = new int[n + 1];
		}
	}// initialize the original and optimal matrix

	 //----------------Recursive Memoized---------------------
	 // Time Complexity O(n^3), Space Complexity O(n^2)
	int RecursiveMatrixMulti(const int * &p, int i, int j) {
		if (m[i][j] != INT_MAX)
			return m[i][j];
		if (i == j)
			m[i][j] = 0;
		for (int k = i; k < j; k++) {
			times_topdown++;
			int q = RecursiveMatrixMulti(p, i, k) + RecursiveMatrixMulti(p, k + 1, j) + p[i - 1] * p[k] * p[j];
			if (q < m[i][j]) {
				m[i][j] = q;
				s[i][j] = k;
			}
		}
		return m[i][j];
	}
	int MatrixMultiMemoized(const int* p) {
		for (int i = 0; i < n + 1; i++)
			for (int j = 0; j < n + 1; j++) {
				m[i][j] = INT_MAX;
				s[i][j] = 0;
			}
		return RecursiveMatrixMulti(p, 1, n);
	}
	//--------------Bottom Up---------------------
	// Time Complexity O(n^3), Space Complexity O(n^2)
	void MatrixMulti(const int* p) {
		for (int i = 0; i < n + 1; i++) {
			for (int j = 0; j < n + 1; j++)
			{
				m[i][j] = 0;
				s[i][j] = 0;
			}
		}
		for (int length = 2; length <= n; length++) {  // length is the length of matrix chain,length=2 means there are 2 subproblems of the matrix
													   // get i
			for (int i = 1; i <= n - length + 1; i++) {
				// get j��-1 means minus A_i�� 
				int j = i + length - 1;
				m[i][j] = INT_MAX;
				for (int k = i; k < j; k++) { //  i <= k < j
					times_bottomup++;
					int q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j];
					if (q < m[i][j]) {
						m[i][j] = q;
						s[i][j] = k;
					}
				}
			}
		}
	}
	//----------------print result with "()"---------------------
	void PrintOptimalParens(int i, int j) {
		if (i == j)
			cout << "A" << i;
		else
		{
			cout << "(";
			PrintOptimalParens(i, s[i][j]); // s[i][j] is optimal value k of��i, j)
			PrintOptimalParens(s[i][j] + 1, j);
			cout << ")";
		}
	}
	//-------------print optimal solution matrix---------------------
	void PrintS() {
		cout << endl << "Print matrix chain s ��" << endl;
		for (int i = 0; i < n + 1; i++) {
			for (int j = 0; j < n + 1; j++)
			{
				cout << s[i][j] << " ";
			}
			cout << endl;
		}
	}
	void printTimes() {
		cout << "Calculation times of Matrix-Multiplication(Bottom Up): " << times_bottomup << endl;
		cout << "Calculation times of Matrix-Multiplication(Top Down memorized): " << times_topdown << endl;
	}

	~Matrix() {
		for (int i = 0; i < n + 1; i++) {
			delete m[i];
			m[i] = NULL;
			delete s[i];
			s[i] = NULL;
		}
		delete m;
		delete s;
		m = NULL;
		s = NULL;
	}
};

int main() {
	const int p[] = { 30, 35, 15, 5, 10, 20, 25 };
	int n = sizeof(p) / sizeof(p[0]) - 1;// get the size of matrix of cols and rows
	cout << "Original matrix chain��";
	for (int i = 1; i <= n; i++)
		cout << "A" << i << " = " << p[i - 1] << " ";
	cout << endl;
	cout << "----------------------------------------------------" << endl;
	Matrix matrix(n);
	cout << "Bottom Up:" << endl;
	matrix.MatrixMulti(p);
	matrix.PrintOptimalParens(1, n);
	matrix.PrintS();
	cout << "----------------------------------------------------" << endl;
	cout << "Recursive Memoized: " << endl;
	matrix.MatrixMultiMemoized(p);
	matrix.PrintOptimalParens(1, n);
	matrix.PrintS();
	matrix.printTimes();
	getchar();
	return 0;
}


