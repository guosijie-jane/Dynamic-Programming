// optimal binary search tree.cpp : Defines the entry point for the console application.
//Sijie Guo's FYP Dynamic Programming Project
#include "stdafx.h"

#include <iostream>
using namespace std;
class BSTree {
private:
	float** e;
	float** w;
	int** root;
	void MatInit(int n) {
		e = new float *[n + 2];  // + 2 is head and tail
		w = new float *[n + 2];
		root = new int *[n + 2];
		for (int i = 0; i < n + 2; i++) {
			e[i] = new float[n + 2];
			w[i] = new float[n + 2];
			root[i] = new int[n + 2];
		}
		for (int i = 0; i < n + 2; i++)
			for (int j = 0; j < n + 2; j++)
				root[i][j] = 0;
	}
public:
	// Time complexity  O(n^3) Space complexity O(n^2)
	void OptimalBST(const float* p, const float* q, int n) {
		MatInit(n);
		for (int i = 1; i <= n + 1; i++) {
			e[i][i - 1] = q[i - 1];
			w[i][i - 1] = q[i - 1];
		}
		for (int l = 1; l <= n; l++) {
			for (int i = 1; i <= n - l + 1; i++) {
				int j = i + l - 1;
				w[i][j] = w[i][j - 1] + p[j] + q[j];
				e[i][j] = INT_MAX;
				for (int r = i; r <= j; r++) {
					float t = e[i][r - 1] + e[r + 1][j] + w[i][j];
					if (t < e[i][j]) {
						e[i][j] = t;
						root[i][j] = r;
					}
				}
			}
		}

	}
	void PrintRoot(int n) {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (root[i][j] == 0)
					cout << "  ";
				else
					cout << root[i][j] << " ";
			}
			cout << endl;
		}
	}
	void PrintOptimalBST(int n) {
		int r = root[1][n];
		cout << "k" << r << " is root." << endl;
		PrintOptimalSubTree(1, r - 1, r, "left child");
		PrintOptimalSubTree(r + 1, n, r, "right child");
	}
private:
	void PrintOptimalSubTree(int i, int j, int r, const char* dir) {
		if (i <= j) {
			int t = root[i][j];
			cout << "k" << t << " is k" << r << "'s " << dir << endl;
			PrintOptimalSubTree(i, t - 1, t, "left child");
			PrintOptimalSubTree(t + 1, j, t, "right child");
		}
		return;
	}

};
int main() {
	/*const float p[] = { 0, 0.15, 0.10, 0.05, 0.10, 0.20 };
	const float q[] = { 0.05, 0.10, 0.05, 0.05, 0.05, 0.10 };
	*/
	/**/
	const float p[] = { 0, 0.05, 0.14, 0.25, 0.02, 0, 0.02, 0.07 };
	const float q[] = { 0.05, 0.10, 0.15, 0.05, 0.05, 0, 0.01, 0.01, 0.01, 0.01, 0.01 };
	/**/
	BSTree bstree;
	int n = sizeof(p) / sizeof(p[0]) - 1;
	bstree.OptimalBST(p, q, n);
	bstree.PrintRoot(n);
	bstree.PrintOptimalBST(n);
	getchar();
}


