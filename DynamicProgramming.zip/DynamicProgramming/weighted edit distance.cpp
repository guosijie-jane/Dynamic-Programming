// weighted edit distance.cpp : Defines the entry point for the console application.
//Sijie Guo's FYP Dynamic Programming Project

#include "stdafx.h"
/*
Weighted edit distance, dynamic programming
used in searching engine
assign weight to keys by Manhattan distance of keyboard
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <iostream>
using namespace std;
/*
string s[3];
int mat[35][35];

int main() {
s[0] = "qwertyuiop";
s[1] = "asdfghjkl;";
s[2] = "zxcvbnm,./";

for (int i = 0; i < 10; i++){
for (int j = 0; j < 3; j++){
for (int k = 0; k < 10; k++){
for (int l = 0; l < 3; l++){
if (j == 1 && i > 8) continue; if (l == 1 && k > 8) continue;
if (j == 2 && i > 6) continue; if (l == 2 && k > 6) continue;
int st1 = s[j][i] - 'a';
int st2 = s[l][k] - 'a';
mat[st1][st2] = abs(j - l) + abs(i - k);
}
}
}
}
for (int i = 0; i < 26; i++){
for (int j = 0; j < 26; j++){
cout << (char)(i + 'a') << " " << (char)(j + 'a') << " " << mat[i][j] << endl;
}
}

return 0;
}*/

const int maxn = 1024;
int dist[32][32];
int dp[maxn][maxn];
int deleteCost = 6;	//cost of deletion
int insertCost = 6;//cost of insertion
char dict[][11] = { "qwertyuiop", "asdfghjkl*", "zxcvbnm***" };// key on keyboard

															   //calculate weight of keys on key board
															   //other weights can be assigned to dist
void calcWeidht()
{
	int row, col, x, y;
	for (row = 0; row < 3; row++)// There are three rows of characters on keyboard
	{
		for (col = 0; col < 10; col++)// There are ten cols of characters on keyboard
		{
			if (dict[row][col] == '*')
			{
				break;
			}
			//calculate dict[row][col]
			for (x = 0; x < 3; x++)
			{
				for (y = 0; y < 10; y++) if (dict[x][y] != '*')
				{
					dist[dict[row][col] - 'a'][dict[x][y] - 'a'] = abs(row - x) + abs(col - y);
				}
			}
		}
	}
}

inline int get_min(int a, int b) { return a < b ? a : b; }

//calculate the edit distance between string A and string B
// assume the length less than maxn-1
int calcEditDist(char A[], char B[])
{
	int lenA = strlen(A);
	int lenB = strlen(B);
	int row, col;

	//initialization on boundry
	for (row = 1; row <= lenA; row++)
	{
		dp[row][0] = row * insertCost;
	}
	for (col = 1; col <= lenB; col++)
	{
		dp[0][col] = col * insertCost;
	}

	//dynamic programming on implementation
	for (row = 1; row <= lenA; row++)
	{
		for (col = 1; col <= lenB; col++)
		{
			int changeCost = (A[row - 1] == B[col - 1] ? 0 : dist[tolower(A[row - 1]) - 'a'][tolower(B[col - 1]) - 'a']);// distance of charaters on key board
			dp[row][col] = get_min(dp[row - 1][col] + deleteCost, get_min(dp[row][col - 1] + deleteCost, dp[row - 1][col - 1] + changeCost));
		}
	}
	cout << "**************************" << endl;
	for (int row = 0; row < lenA + 1; row++)
	{
		for (int col = 0; col < lenB + 1; col++)
		{
			cout << dp[row][col] << " ";
		}
		cout << endl;
	}
	cout << "**************************" << endl;
	return dp[lenA][lenB];
}

int main()
{
	char strA[maxn], strB[maxn];
	calcWeidht();
	cout << "Please input original string and misspelling string:  " << endl;
	cout << "source: ";
	cin >> strA;
	cout << "target: ";
	cin >> strB;
	//while (cin>> strA>> strB)
	{
		cout << "The weighted edit distance between " << strA << " and " << strB << " is " << calcEditDist(strA, strB) << endl;

	}
}